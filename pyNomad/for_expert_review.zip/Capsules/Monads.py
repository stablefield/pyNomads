"""
The base class for all monads.
"""


from typing import Any, Generic, TypeVar
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

T = TypeVar("T")
U = TypeVar("U")


class Monad(Generic[T]):
    """
    Identity monad (also the parent class for all other monads).

    No additional work is handled on function calls, apart from returning
    a new monad with an updated result.

    Can be used like so:

    ```python
    def make_loud(x:str) -> str:
        return x.upper()

    x = Monad("hello world!") >> make_loud

    print(x.value)
    # prints out "HELLO WORLD!"
    ```
    """

    def __init__(self: Any, value: T) -> None:
        """
        Initialise a monad with the given value
        """
        self.value: T = value

    def bind(self, func) -> "Monad":
        """
        Method to apply function to value of Monad.
        Returns a monad with the updated value.

        Example:
        ```python
        Monad(2).bind(lambda x: x+1) == Monad(3)
        ```

        Can be aliased with `>>` symbol:
        ```python
        (Monad(2) >> (lambda x: x+1)) == Monad(3)
        """
        return Monad(func(self.value))

    def __rshift__(self, other) -> "Monad":
        """
        Dunder method to alias bind into >>
        """
        return self.bind(other)

    def __lshift__(self, other) -> "Monad":
        """
        Dunder method to alias bind into <<
        return self.bind(other). Executes as other(self.value)
        on the right hand side of the operator.
        For alternative syntax:
        ```python
        Monad(2) >> (lambda x: x+1) == x=2 << (lambda x: x+1)


        ```
        """
        return self.bind(other)

    def unwrap(self) -> T:
        """
        Return only the value of the monad without wrapping
        it.

        ```python
        Monad(4).unwrap() == 4
        ```
        """
        return self.value

    def __str__(self) -> str:
        """
        String representation
        """
        return f"{self.__class__.__name__}({self.value})"

    def __repr__(self) -> str:
        """
        For repls
        """
        return self.__str__()


if ___name__ == "__main__":

    from pyNomads.Capsules.Monads import Monad
    x = Monad(3)
    print(x)
    print(x.value)
    math = x >> (lambda x: x+1).bind(lambda x: x*2)ma  