"""

"""


class Compound(Monad, Generic[T]):
    def __init__(self: Any, value: T) -> None:
        """
        Initialise a monad with the given value. This is a compound monad
        meaning that it can be used to chain functions together without
        executing them. They will be executed when the monad is unwrapped.

        This is useful for creating a call graph of functions that can be
        executed later. This is useful for creating a call graph of functions
        in the case of an error, where you want to know what functions were
        executed before the error occurred and in what order so that you can
        recover from the error precisely without having to re-execute the
        entire call graph.
        A retry function is also provided to allow for alternative strategies

        """
        super().__init__(value)
        self.call_graph = []  # Initialize call graph
        self.error = None
        self.signature = self.sign(value)
        self.value = copy.deepcopy(value)

    def sign(self, value: T) -> str:
        return hashlib.sha256(str(value).encode()).hexdigest()

    async def bind(self, func) -> "Monad":
        """
        Bind a asynchronous function to the call graph to execute later.
        """
        self.call_graph.append(func)  # Update call graph
        compile = asyncio.create_task(self.alternate_bind(func, lambda x: x, lambda x: x))
        re
        try:
            if asyncio.iscoroutinefunction(func):
                self.value = await func(self.value)
            else:
                self.value = func(self.value)
            self.check(self.value, self.signature)  # Check the value
        except ZeroDivisionError as e:
            logger.error(f"{e} - {route}")

            self.value = self.retry(func, lambda x: 0)  # Retry with alternative strategy
        except Exception as e:
            self.error = e
        return self

    def check(self, value: T, signature: str) -> None:
        assert self.sign(value) == signature, "Value corruption detected"

    def __lshift__(self, other) -> "Monad":
        self.call_graph.append(other)  # Update call graph
        return asyncio.run(self.bind(other))

    def retry(self, func, alternative) -> "Monad":
        """
        Retry a function with an alternative strategy
        :param func: Function being bound to ideal strategy
        :param alternative: Alternative strategy
        """
        try:
            return self >> func  # Try the original operation
        except Exception as e:
            self.error = e
            return self >> alternative  # If it fails, try the alternative

    def unwrap(self) -> Tuple[T, Optional[Exception], str]:
        return self.value, self.error, str(self.call_graph)

    def generate_graph(self) -> str:
        """
        Generate a graph of the call graph
        """
        graph = "graph TD\n"
        for i, func in enumerate(self.call_graph):
            graph += f"A{i}[{func.__name__}]\n"
            if i > 0:
                graph += f"A{i - 1} --> A{i}\n"
        return graph

    async def alternate_bind(self, func, alternative, final) -> "Monad":
        """
        Bind function to monad, retrying with alternative if it fails.
        """
        try:
            return await self.bind(func)
        except TypeError as e:  # Catching NoneType exception
            try:
                return await self.retry(func, alternative)
            except Exception as f:
                self.error = f
            finally:
                # If the alternative fails, return the final value
                return await self.bind(final)